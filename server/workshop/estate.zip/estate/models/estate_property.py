from odoo import api, fields, models
from odoo.exceptions import UserError

class EstateProperty(models.Model) :
    _name = "estate.property"
    _description = "Real Estate Property"

    name = fields.Char()
    description = fields.Text()
    date = fields.Date()
    expected_price = fields.Float()
    selling_price = fields.Float()
    bedrooms = fields.Integer()
    outdoor_area = fields.Float()
    living_area = fields.Integer()
    has_garden = fields.Boolean()
    garden_area = fields.Integer()

    total_area = fields.Integer(compute="_compute_total_area")

    offer_ids = fields.One2many("estate.property.offer", "property_id")

    best_price = fields.Float(compute="_compute_best_price", string="Best Offer")

    property_type_id = fields.Many2one("estate.property.type", string="Property Type")
    
    buyer_id = fields.Many2one('res.partner')
    
    sales_person_id = fields.Many2one('res.users', string = "Salesman", default = lambda self:self.env.user)

    tag_ids = fields.Many2many("estate.property.tag")


    state = fields.Selection (
        selection = [('new', 'New'), ('offer_received', 'Offer Received'), ('offer_accepted', 'Offer Accepted'), ('sold', 'Sold') , ('cancelled', 'Cancelled')],
        default = 'new', 
        required = True,
    )

    @api.depends("living_area", "garden_area")
    def _compute_total_area(self):
        for record in self:
            record.total_area = record.living_area + record.garden_area

    @api.depends("offer_ids.price")
    def _compute_best_price(self):
        for record in self:
            if record.offer_ids:
                record.best_price = max(record.offer_ids.mapped("price"))
            else:
                record.best_price = 0.0

    
    def sell_property(self):
        for record in self:
            if record.state == 'cancelled':
                raise UserError("Cancelled Property, so can't be Sold")
            else:
                record.state = 'sold'

    def cancel_property(self):
        for record in self:
            if record.state == 'sold':
                raise UserError("Sold Property, so can't be Cancelled")
            else:
                record.state = 'cancelled'


    _check_expected_price = models.Constraint(
        'CHECK(expected_price > 0)',
        'The expected price must be more than 0',
    )

    _check_selling_price = models.Constraint(
        'CHECK(expected_price >= 0)',
        'The expected price must be equal and more than 0',
    )