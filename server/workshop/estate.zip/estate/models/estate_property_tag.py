from odoo import api, fields, models

class EstatePropertyTag(models.Model):
    _name = "estate.property.tag"
    _description = "Real Estate Property Tags"

    name = fields.Char()
    color = fields.Integer("Color")

    _check_tag_name = models.Constraint(
        'UNIQUE(name)',
        'The Property name should be unique',
    )