from odoo import api, fields, models
from odoo.exceptions import UserError

class EstatePropertyOffer(models.Model):
    _name = "estate.property.offer"
    _description = "Real Estate Property Offer"

    name = fields.Char()

    price = fields.Float ()
    partner_id = fields.Many2one('res.partner')
    property_id = fields.Many2one('estate.property')

    status = fields.Selection(selection=[('accepted', 'Accepted'), ('refused', 'Refused')] )


    def accepted_offer(self):
        for record in self:
            if record.property_id.state == 'offer_accepted':
                raise UserError("This property already has an Offer Accepted")
            else:
                record.status = 'accepted'
                record.property_id.write({
                    "buyer_id" : record.partner_id.id,
                    "selling_price": record.price,
                    "state": "offer_accepted",
                })
        

    def refused_offer(self):
        for record in self:
            if record.status == 'accepted':
                raise UserError("Accepted Offers cannot be refused")
            else:
                record.status = 'refused'
                


    _check_offer_price = models.Constraint(
        'CHECK(offer_price > 0)',
        'The offer price must be more than 0',
    )