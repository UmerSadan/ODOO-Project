from odoo import api, fields, models

class EstatePropertyType(models.Model):
    _name = "estate.property.type"
    _description = "Real Estate Property Type"

    name = fields.Char()

    property_id = fields.One2many("estate.property", "property_type_id")

    _check_type_name = models.Constraint(
        'UNIQUE(name)',
        'The Property name should be unique',
    )